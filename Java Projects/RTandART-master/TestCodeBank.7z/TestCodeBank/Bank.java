public class Bank {
    String name;
    double balance;
    public Bank(String name, double balance)
    {
        this.name=name;
        this.balance = balance;
    }
}
