public class Test {
    private Bank bank;
    
    public static void main(String[] args) {
        String name = String.valueOf(args[0]);
        double bal = Double.parseDouble(args[1]);

        Bank bank = new Bank(name, bal);

        Test myBank = new Test(bank); //creates new MyCalendar Object
        
        myBank.deposit(bank.balance);
        myBank.withdraw(bank.balance);
    }
    
    public Test(Bank bank)
    {
        this.bank=bank;
    }
    
    public void deposit(double amount)
    {
        bank.balance += amount;
    }
    
    public void withdraw(double amount)
    {
        bank.balance -= amount;
    }
}
